package com.jarvis.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale
import java.util.UUID

enum class JState { Idle, Listening, Thinking, Done }

/** text = what Jarvis says. confirm = if set, runs only after user says "haan". */
data class Reply(val text: String, val confirm: (() -> String)? = null, val next: (suspend () -> Reply)? = null)

object Jarvis {
    val state = MutableStateFlow(JState.Idle)
    val history = MutableStateFlow<List<String>>(emptyList())
    val speaking = MutableStateFlow(false)
    val mood = MutableStateFlow("calm")   // avatar isse badalta hai
    var pending: Reply? = null
    private var tts: TextToSpeech? = null
    private var ready = false
    private var cur = ""
    private var appCtx: Context? = null

    fun init(c: Context) {
        if (tts != null) return
        appCtx = c.applicationContext
        tts = TextToSpeech(c.applicationContext) {
            ready = it == TextToSpeech.SUCCESS; tts?.language = Locale("en", "IN")
            c.getSharedPreferences("jarvis", 0).getString("voice", null)?.let { n -> tts?.voices?.firstOrNull { v -> v.name == n }?.let { v -> tts?.voice = v } }
        }
    }

    fun speak(text: String, add: Boolean = false, done: () -> Unit = {}) {
        val t = tts
        val main = Handler(Looper.getMainLooper())
        if (!ready || t == null) { main.post(done); return }
        val id = UUID.randomUUID().toString(); cur = id
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) { speaking.value = true }
            override fun onDone(u: String?) { if (u == cur) { speaking.value = false; main.post(done) } }
            @Deprecated("") override fun onError(u: String?) { if (u == cur) { speaking.value = false; main.post(done) } }
        })
        appCtx?.getSharedPreferences("jarvis", 0)?.let { t.setPitch(it.getFloat("pitch", 1f)); t.setSpeechRate(it.getFloat("rate", 1f)) }
        t.speak(text, if (add) TextToSpeech.QUEUE_ADD else TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun nextVoice(): String {
        val t = tts ?: return ""
        val vs = t.voices.filter { it.locale.language in listOf("en", "hi") && !it.isNetworkConnectionRequired }.sortedBy { it.name }
        if (vs.isEmpty()) return ""
        val v = vs[(vs.indexOfFirst { it.name == t.voice?.name } + 1) % vs.size]
        t.voice = v; appCtx?.getSharedPreferences("jarvis", 0)?.edit()?.putString("voice", v.name)?.apply()
        return v.name
    }

    private fun log(s: String) { history.value = (history.value + s).takeLast(30) }

    suspend fun handle(c: Context, raw: String): Reply {
        state.value = JState.Thinking; mood.value = "focused"
        log("You: $raw")
        val p = pending; pending = null
        val t = raw.lowercase()
        val reply = when {
            p == null -> { Memory.bump(c, raw); Router.run(c, raw) }
            Regex("\\b(nahi|nahin|no|cancel|ruk|mat|stop)\\b").containsMatchIn(t) -> { Agent.auto = false; Reply("Theek hai bhai, cancel kar diya.") }
            Regex("\\b(haan|han|yes|yeah|kar de|kardo|kar do|ok|okay|theek|sure|pakka)\\b").containsMatchIn(t) -> {
                if ("sab" in t) Agent.auto = true
                p.next?.invoke() ?: Reply(p.confirm!!())
            }
            else -> Reply("Samajh nahi aaya, isliye cancel kar diya.")
        }
        pending = if (reply.confirm != null || reply.next != null) reply else null
        log("Jarvis: ${reply.text}")
        state.value = JState.Done
        return reply
    }
}
