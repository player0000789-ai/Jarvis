package com.jarvis.assistant

import android.Manifest
import android.app.DownloadManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.accessibilityservice.AccessibilityService
import kotlinx.coroutines.delay
import java.util.Calendar

/** Naya command add karna ho: Command implement kar, Router.register(...) kar de. Bas. */
interface Command {
    val ask: Boolean get() = true               // false = ask-first wala sawaal skip
    fun matches(t: String): Boolean            // t = lowercase text
    suspend fun run(c: Context, raw: String): Reply  // raw = original text
}

object Router {
    val commands = mutableListOf<Command>(MemoryCmd, AlarmCmd, SearchCmd, TypeCmd, MediaCmd, SystemCmd, NavCmd, ClickCmd, OpenAppCmd)
    fun register(cmd: Command) { commands.add(0, cmd) }
    private fun known(t: String) = commands.any { it.matches(t) }

    /** ask = true: pehle puchta hai. Jo built-in command nahi hai wo Agent ko jata hai (wo har step puchta hai). */
    suspend fun run(c: Context, raw: String, ask: Boolean = c.getSharedPreferences("jarvis", 0).getBoolean("ask", true)): Reply {
        val parts = raw.split(Regex("\\s+(aur|phir|fir|then)\\s+", RegexOption.IGNORE_CASE))
        val chain = parts.size > 1 && parts.all { known(it.lowercase()) }
        if (!chain && !known(raw.lowercase())) return Agent.start(c, raw)
        if (ask && (chain || commands.first { it.matches(raw.lowercase()) }.ask)) return Reply("Main ye karunga: \"$raw\". Kar du?", next = { run(c, raw, false) })
        if (chain) {
            for (p in parts) { val r = exec(c, p); if (r.confirm != null) return r; delay(1200) }
            return Reply("Ho gaya bhai, sab kar diya.")
        }
        return exec(c, raw)
    }
    private suspend fun exec(c: Context, raw: String) =
        commands.firstOrNull { it.matches(raw.lowercase()) }?.run(c, raw.trim()) ?: Reply("Ye samajh nahi aaya bhai, firse bol.")
}

fun Context.go(i: Intent): Boolean = try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (e: Exception) { false }
fun Context.has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
fun strip(raw: String, words: String) = raw.replace(Regex("\\b($words)\\b", RegexOption.IGNORE_CASE), " ").replace(Regex("\\s+"), " ").trim()
fun needA11y(c: Context): Reply? = if (JarvisA11y.inst != null) null else {
    c.go(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    Reply("Bhai, iske liye mujhe Accessibility permission chahiye. Settings mein enable kar de.")
}

object OpenAppCmd : Command {
    override fun matches(t: String) = Regex("\\b(khol\\w*|open|chala\\w*|launch|start)\\b").containsMatchIn(t)
    override suspend fun run(c: Context, raw: String): Reply {
        val name0 = strip(raw, "khol\\w*|open|chala\\w*|launch|start|kar|karo|jarvis|bhai|ko|app|please|de|do|mein|me|ka|ki|ek|zara|jaldi").lowercase()
        val name = Memory.alias(c, name0) ?: name0
        if (name.isBlank()) return Reply("Kya kholu bhai?")
        findApp(c, name)?.let { if (c.go(it)) return Reply("Ho gaya bhai, $name khul gaya.") }
        val url = if ('.' in name) name else name.replace(" ", "") + ".com"
        return if (c.go(Intent(Intent.ACTION_VIEW, Uri.parse("https://$url")))) Reply("$name app nahi mila, browser mein khol diya.")
        else Reply("Ye nahi khul raha bhai.")
    }
    fun findApp(c: Context, name: String): Intent? {
        val pm = c.packageManager
        val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = l.map { it.activityInfo.packageName to it.loadLabel(pm).toString().lowercase() }
            .filter { (_, lb) -> lb == name || lb.contains(name) || (lb.length > 2 && name.contains(lb)) }
            .minByOrNull { kotlin.math.abs(it.second.length - name.length) }
        return hit?.let { pm.getLaunchIntentForPackage(it.first) }
    }
}

object SystemCmd : Command {
    override fun matches(t: String) = Regex("\\b(settings?|bluetooth|wifi|wi-fi|gallery|calculator|downloads?)\\b").containsMatchIn(t)
    override suspend fun run(c: Context, raw: String): Reply {
        val t = raw.lowercase()
        fun sel(cat: String) = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, cat)
        return when {
            "bluetooth" in t -> { c.go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); Reply("Bhai, Android apps ko Bluetooth direct on/off nahi karne deta. Settings khol di, switch tu daba de.") }
            "wifi" in t || "wi-fi" in t -> { c.go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)); Reply("Wi-Fi panel khol diya bhai.") }
            "setting" in t -> { c.go(Intent(Settings.ACTION_SETTINGS)); Reply("Settings khol di bhai.") }
            "download" in t -> { c.go(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); Reply("Ye le bhai, Downloads folder.") }
            "gallery" in t -> if (c.go(sel(Intent.CATEGORY_APP_GALLERY))) Reply("Gallery khul gayi bhai.") else OpenAppCmd.run(c, "gallery open")
            else -> if (c.go(sel(Intent.CATEGORY_APP_CALCULATOR))) Reply("Calculator khul gaya bhai.") else OpenAppCmd.run(c, "calculator open")
        }
    }
}

object AlarmCmd : Command {
    override fun matches(t: String) = "alarm" in t
    override suspend fun run(c: Context, raw: String): Reply {
        val t = raw.lowercase()
        val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?").find(t)
            ?: run { c.go(Intent(AlarmClock.ACTION_SHOW_ALARMS)); return Reply("Kitne baje ka laga du bhai? Time bolke bata.") }
        var h = m.groupValues[1].toInt(); val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        if (Regex("\\b(pm|shaam|sham|raat|dopahar)\\b").containsMatchIn(t) && h < 12) h += 12
        if (h > 23 || min > 59) return Reply("Ye time galat lag raha hai bhai, firse bol.")
        val ok = c.go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, min)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true).putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis"))
        return Reply(if (ok) "Alarm laga diya bhai, %d:%02d ka.".format(h, min) else "Alarm app nahi khul raha bhai.")
    }
}

object SearchCmd : Command {
    override fun matches(t: String) = "search" in t || "google pe" in t
    override suspend fun run(c: Context, raw: String): Reply {
        val q = strip(raw, "google|pe|par|search|kar|karo|me|mein|jarvis|bhai|for|ko|dhoond")
        if (q.isBlank()) return Reply("Kya search karu bhai?")
        c.go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        return Reply("Ye dekh bhai, '$q' search kar diya.")
    }
}

object TypeCmd : Command {
    override fun matches(t: String) = Regex("\\b(type|bhar|likh)\\b").containsMatchIn(t)
    override suspend fun run(c: Context, raw: String): Reply {
        val t = raw.lowercase()
        if (Regex("password|otp|\\bpin\\b|cvv|card number").containsMatchIn(t)) return Reply("Bhai, password/OTP jaisi cheez main type nahi karunga, ye khud daal le.")
        if (Regex("mera (email|number|phone|address)").containsMatchIn(t)) return Reply("Bhai, mere paas teri personal details saved nahi hain. Bol de kya type karna hai.")
        val text = Regex("naam\\s+(.+?)\\s+bhar", RegexOption.IGNORE_CASE).find(raw)?.groupValues?.get(1)
            ?.split(" ")?.joinToString(" ") { it.replaceFirstChar(Char::uppercase) }
            ?: Regex("(.+?)\\s+(?:type|likh)\\s+kar", RegexOption.IGNORE_CASE).find(raw)?.groupValues?.get(1)
            ?: Regex("(?:type|likh)\\s+(?:kar\\s+)?(.+)", RegexOption.IGNORE_CASE).find(raw)?.groupValues?.get(1)
            ?: return Reply("Kya type karu bhai?")
        needA11y(c)?.let { return it }
        return Reply(if (JarvisA11y.inst!!.typeText(text)) "Type kar diya bhai." else "Koi text box select nahi mila, pehle field pe tap kar de.")
    }
}

object ClickCmd : Command {
    override fun matches(t: String) = Regex("\\b(daba\\w*|press|click|tap|submit)\\b").containsMatchIn(t)
    private val risky = Regex("submit|pay|buy|order|place|confirm|delete|remove|purchase|send|checkout|book|transfer|logout|sign out")
    override suspend fun run(c: Context, raw: String): Reply {
        val label = strip(raw, "button|ko|ka|press|click|tap|kar|karo|jarvis|bhai|daba\\w*|is|page|on|the|ek|baar|do").lowercase()
        if (label.isBlank()) return Reply("Kaunsa button bhai?")
        needA11y(c)?.let { return it }
        val act = { if (JarvisA11y.inst?.clickText(label) == true) "Daba diya bhai." else "'$label' screen pe nahi dikha bhai." }
        return if (risky.containsMatchIn(label)) Reply("Bhai, pakka '$label' dabana hai? Haan bol de.", act) else Reply(act())
    }
}

object NavCmd : Command {
    override fun matches(t: String) = Regex("\\b(back|wapas|peeche|home|recents?|notifications?)\\b").containsMatchIn(t)
    override suspend fun run(c: Context, raw: String): Reply {
        needA11y(c)?.let { return it }
        val t = raw.lowercase()
        val a = when {
            "home" in t -> AccessibilityService.GLOBAL_ACTION_HOME
            "recent" in t -> AccessibilityService.GLOBAL_ACTION_RECENTS
            "notification" in t -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            else -> AccessibilityService.GLOBAL_ACTION_BACK
        }
        JarvisA11y.inst!!.global(a); return Reply("Ho gaya bhai.")
    }
}

object MediaCmd : Command {
    override fun matches(t: String) = Regex("\\b(photos?|pics?|pictures?|images?|screenshots?|pdf|files?|download\\w*)\\b").containsMatchIn(t)
    private val months = listOf("january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december")
    override suspend fun run(c: Context, raw: String): Reply {
        val t = raw.lowercase()
        if (Regex("pdf|file|download").containsMatchIn(t)) {
            c.go(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
            return Reply("Bhai, Android ab dusre apps ki files search nahi karne deta. Downloads khol diya, wahan se utha le.")
        }
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
        if (!c.has(perm)) return Reply("Bhai, photos ke liye mujhe Photos permission chahiye. App mein allow kar de.")
        val conds = mutableListOf("1=1"); val args = mutableListOf<String>()
        if ("screenshot" in t) { conds += "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?"; args += "%Screenshots%" }
        val mi = months.indexOfFirst { Regex("\\b$it\\b").containsMatchIn(t) }
        if (mi >= 0) {
            val cal = Calendar.getInstance(); if (mi > cal.get(Calendar.MONTH)) cal.add(Calendar.YEAR, -1)
            cal.set(cal.get(Calendar.YEAR), mi, 1, 0, 0, 0); cal.set(Calendar.MILLISECOND, 0)
            val s = cal.timeInMillis; cal.add(Calendar.MONTH, 1)
            conds += "${MediaStore.Images.Media.DATE_TAKEN} >= ? AND ${MediaStore.Images.Media.DATE_TAKEN} < ?"
            args += s.toString(); args += cal.timeInMillis.toString()
        }
        val id = c.contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Images.Media._ID),
            conds.joinToString(" AND "), args.toTypedArray(), "${MediaStore.Images.Media.DATE_TAKEN} DESC")
            ?.use { if (it.moveToFirst()) it.getLong(0) else null } ?: return Reply("Aisi koi photo nahi mili bhai.")
        val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
        c.go(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "image/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        return Reply("Ye le bhai, photo khol di.")
    }
}
