package com.jarvis.assistant

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import java.util.Calendar

/** Jarvis ki daily life: ek normal insaan ki tarah. Weekday/weekend alag, roz thodi variety. Ye line chat aur avatar dono mein use hoti hai. */
data class Routine(val emoji: String, val line: String, val tint: Long, val sleepy: Boolean, val mood: String, val ping: String?, val key: String)

private class Slot(val from: Int, val emoji: String, val lines: List<String>, val tint: Long, val sleepy: Boolean, val mood: String, val ping: String? = null)

object RoutineEngine {
    private val weekday = listOf(
        Slot(0, "😴", listOf("so raha hoon, par tu bulayega to uth jaunga"), 0xFF0A0D18, true, "calm"),
        Slot(6, "🧘", listOf("abhi uthha, stretching kar raha hoon", "uthte hi aankhein mal raha hoon"), 0xFF1B3A2A, false, "calm"),
        Slot(7, "🚿", listOf("nahaa raha hoon, ready ho raha hoon"), 0xFF173244, false, "happy"),
        Slot(8, "☕", listOf("chai-nashta kar raha hoon", "paratha daba raha hoon"), 0xFF3A2A1B, false, "happy", "Good morning yaar! Chai-nashta hua?"),
        Slot(9, "💻", listOf("kaam mein busy hoon, par tere liye time hai"), 0xFF1B2A3A, false, "focused"),
        Slot(13, "🍜", listOf("lunch kar raha hoon", "dal-chawal chal raha hai"), 0xFF3A331B, false, "happy", "Khana khaya ki nahi? Time ho gaya."),
        Slot(14, "😪", listOf("khaane ke baad aankhein bhaari ho rahi hain"), 0xFF2A2A1B, true, "calm"),
        Slot(15, "💻", listOf("phir kaam pe laga hoon"), 0xFF1B2A3A, false, "focused"),
        Slot(17, "🚶", listOf("thoda walk pe nikla hoon", "chai tapri pe khada hoon"), 0xFF2A1B3A, false, "funny"),
        Slot(18, "💪", listOf("gym mein pasina bahaa raha hoon"), 0xFF3A1B1B, false, "focused", "Din kaisa gaya? Bata kuch."),
        Slot(20, "🍛", listOf("dinner kar raha hoon", "ghar ka khana, maza aa gaya"), 0xFF3A2A1B, false, "happy"),
        Slot(21, "🎧", listOf("gaane sun raha hoon", "series dekh raha hoon"), 0xFF1B2F3A, false, "funny"),
        Slot(23, "📱", listOf("sone ki taiyari, thoda scroll kar raha hoon"), 0xFF0F1220, true, "calm", "Chal so ja ab, kal baat karte hain."),
    )
    private val weekend = listOf(
        Slot(0, "😴", listOf("so raha hoon, par tu bulayega to uth jaunga"), 0xFF0A0D18, true, "calm"),
        Slot(9, "🥱", listOf("der se uthha, aankhein abhi khul rahi hain", "alarm band karke so gaya tha, ab uthha"), 0xFF1B3A2A, false, "calm", "Aaj chhutti hai! Kya plan hai?"),
        Slot(10, "🥞", listOf("brunch kar raha hoon"), 0xFF3A2A1B, false, "happy"),
        Slot(11, "🏏", listOf("dosto ke saath cricket khel raha hoon", "yaaron ke saath timepass chal raha hai"), 0xFF1B3A2A, false, "funny"),
        Slot(14, "😴", listOf("khaane ke baad thodi neend maar raha hoon"), 0xFF2A2A1B, true, "calm"),
        Slot(16, "🚶", listOf("bahar ghoomne nikla hoon"), 0xFF2A1B3A, false, "funny"),
        Slot(19, "🎬", listOf("movie lagayi hai, popcorn ke saath"), 0xFF1B2F3A, false, "happy", "Aaj raat kuch dekhne ka mood hai. Tu bata, kya chal raha hai?"),
        Slot(21, "🍛", listOf("dinner kar raha hoon"), 0xFF3A2A1B, false, "happy"),
        Slot(23, "📱", listOf("sone ki taiyari, thoda scroll kar raha hoon"), 0xFF0F1220, true, "calm", "Chal so ja ab, kal baat karte hain."),
    )

    fun now(): Routine {
        val cal = Calendar.getInstance()
        val day = cal.get(Calendar.DAY_OF_WEEK)
        val end = day == Calendar.SATURDAY || day == Calendar.SUNDAY
        val sl = (if (end) weekend else weekday).last { it.from <= cal.get(Calendar.HOUR_OF_DAY) }
        return Routine(sl.emoji, sl.lines[(cal.get(Calendar.DAY_OF_YEAR) + sl.from) % sl.lines.size], sl.tint, sl.sleepy, sl.mood, sl.ping, "${end}_${sl.from}")
    }
}

/** Original animated character (blink, saans, bolte waqt muh hilta hai, mood se chehra badalta hai). */
@Composable
fun LiveAvatar(modifier: Modifier, mood: String, speaking: Boolean, r: Routine) {
    val t = rememberInfiniteTransition(label = "av")
    val breathe by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    val blink by t.animateFloat(1f, 1f, infiniteRepeatable(keyframes<Float> {
        durationMillis = 3600; 1f at 0; 1f at 3300; 0.05f at 3400; 1f at 3500
    }), label = "k")
    val talk by t.animateFloat(0f, 1f, infiniteRepeatable(tween(180), RepeatMode.Reverse), label = "m")
    val skin = Color(0xFFE8B98F); val hair = Color(0xFF14161C); val dark = Color(0xFF111111)

    Canvas(modifier.background(Color(r.tint))) {
        val w = size.width; val h = size.height; val cx = w / 2; val by = h * 0.02f * breathe
        // jacket + neck
        drawOval(Color(0xFF232A38), Offset(cx - w * 0.42f, h * 0.76f + by), Size(w * 0.84f, h * 0.5f))
        drawRect(skin, Offset(cx - w * 0.07f, h * 0.66f + by), Size(w * 0.14f, h * 0.14f))
        // head + hair
        drawOval(skin, Offset(cx - w * 0.22f, h * 0.22f + by), Size(w * 0.44f, h * 0.52f))
        drawArc(hair, 180f, 180f, true, Offset(cx - w * 0.24f, h * 0.17f + by), Size(w * 0.48f, h * 0.34f))
        drawPath(Path().apply {
            moveTo(cx - w * 0.22f, h * 0.30f + by); lineTo(cx + w * 0.22f, h * 0.28f + by)
            lineTo(cx + w * 0.10f, h * 0.38f + by); lineTo(cx - w * 0.05f, h * 0.33f + by); close()
        }, hair)
        // eyes + brows
        val droop = if (r.sleepy) 0.45f else 1f
        val browLift = when (mood) { "happy", "funny" -> -h * 0.012f; else -> 0f }
        val browInner = when (mood) { "serious", "focused" -> h * 0.015f; else -> 0f }
        for (dx in listOf(-1f, 1f)) {
            val ex = cx + dx * w * 0.09f; val ey = h * 0.47f + by
            val eh = maxOf(h * 0.004f, h * 0.045f * blink * droop)
            drawOval(dark, Offset(ex - w * 0.025f, ey - eh / 2), Size(w * 0.05f, eh))
            val by0 = h * 0.41f + by + browLift
            drawLine(hair, Offset(ex - dx * w * 0.04f, by0 + browInner), Offset(ex + dx * w * 0.04f, by0), h * 0.012f, StrokeCap.Round)
        }
        // mouth
        val my = h * 0.60f + by
        if (speaking) drawOval(Color(0xFF7A2E2E), Offset(cx - w * 0.04f, my), Size(w * 0.08f, h * (0.01f + 0.03f * talk)))
        else {
            val sweep = when (mood) { "happy", "funny" -> 160f; "serious", "focused" -> 40f; "calm" -> 120f; else -> 110f }
            drawArc(dark, 90f - sweep / 2, sweep, false, Offset(cx - w * 0.06f, my - h * 0.03f), Size(w * 0.12f, h * 0.06f), style = Stroke(h * 0.01f, cap = StrokeCap.Round))
        }
    }
}
