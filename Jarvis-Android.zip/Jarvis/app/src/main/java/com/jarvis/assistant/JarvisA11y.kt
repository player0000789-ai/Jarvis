package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Sirf voice command par kaam karta hai. Passwords/OTP kabhi store ya type nahi hote (TypeCmd block karta hai). */
class JarvisA11y : AccessibilityService() {
    companion object { @Volatile var inst: JarvisA11y? = null }
    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun global(a: Int) = performGlobalAction(a)

    fun typeText(s: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val n = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: firstEditable(root) ?: return false
        val old = if (n.isShowingHintText) "" else n.text?.toString() ?: ""
        val sep = if (old.isNotEmpty() && !old.endsWith(" ")) " " else ""
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, old + sep + s)
        })
    }

    fun clickText(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(label)) {
            var x: AccessibilityNodeInfo? = n
            while (x != null && !x.isClickable) x = x.parent
            if (x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) return true
        }
        return false
    }

    private var cache = listOf<AccessibilityNodeInfo>()

    /** Screen ko numbered list bana deta hai (password fields ka text nahi jaata). */
    fun dump(): String {
        val root = rootInActiveWindow ?: return "(screen unavailable)"
        val list = mutableListOf<AccessibilityNodeInfo>(); val sb = StringBuilder("app: ${root.packageName}\n")
        walk(root, list, sb); cache = list
        return sb.toString().take(6000)
    }
    private fun walk(n: AccessibilityNodeInfo, list: MutableList<AccessibilityNodeInfo>, sb: StringBuilder) {
        if (!n.isVisibleToUser) return
        val label = (n.text ?: n.contentDescription)?.toString()?.take(60)
        if (n.isClickable || n.isEditable || n.isScrollable || !label.isNullOrBlank()) {
            val kind = when { n.isEditable -> "input"; n.isClickable -> "button"; n.isScrollable -> "scroll"; else -> "text" }
            sb.append("[${list.size}] $kind \"${if (n.isPassword) "[PASSWORD FIELD]" else label ?: ""}\"\n"); list.add(n)
        }
        for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, list, sb) }
    }
    fun label(id: Int) = cache.getOrNull(id)?.let { (it.text ?: it.contentDescription)?.toString() } ?: ""
    fun clickId(id: Int): Boolean {
        var x = cache.getOrNull(id)
        while (x != null && !x.isClickable) x = x.parent
        return x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }
    fun typeId(id: Int, s: String): Boolean {
        val n = cache.getOrNull(id) ?: return false
        if (n.isPassword) return false
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s) })
    }
    fun scroll(fwd: Boolean): Boolean {
        val n = cache.firstOrNull { it.isScrollable } ?: return false
        return n.performAction(if (fwd) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    private fun firstEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable) return n
        for (i in 0 until n.childCount) n.getChild(i)?.let { firstEditable(it)?.let { f -> return f } }
        return null
    }
}
