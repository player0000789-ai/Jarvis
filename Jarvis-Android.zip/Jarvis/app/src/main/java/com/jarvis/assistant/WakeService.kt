package com.jarvis.assistant

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.*
import android.provider.Settings
import android.speech.*
import kotlinx.coroutines.*

/** Background wake-word listener. "Jarvis" sunte hi active. Wake-word engine badalna ho (Porcupine etc.) toh sirf ye file touch kar. */
class WakeService : Service(), RecognitionListener {
    private val h = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var sr: SpeechRecognizer? = null
    private var cmdMode = false
    private val wakeRe = Regex("jarvis|जार्विस|जारविस|जर्विस|जार्विज", RegexOption.IGNORE_CASE)
    private var bubble: Bubble? = null
    private var collecting = false
    private var pinging = false
    private val pingLoop = object : Runnable { override fun run() { checkPing(); h.postDelayed(this, 600_000) } }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate(); Jarvis.init(this)
        getSystemService(NotificationManager::class.java).apply {
            createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
            createNotificationChannel(NotificationChannel("jarvis_chat", "Jarvis dost", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val n = Notification.Builder(this, "jarvis").setContentTitle("Jarvis sun raha hai").setContentText("\"Jarvis\" bol ke jaga de")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        syncBubble()
        if (!pinging) { pinging = true; h.post(pingLoop) }
        if (i?.action == "TAP") wake() else if (sr == null && wakeOn()) listen()
        return START_STICKY
    }

    private fun bubbleOn() = getSharedPreferences("jarvis", MODE_PRIVATE).getBoolean("bubble", true) && Settings.canDrawOverlays(this)
    private fun syncBubble() {
        if (!bubbleOn()) { bubble?.hide(); return }
        if (bubble == null) bubble = Bubble(this) { wake() }
        bubble?.show()
        if (!collecting) {
            collecting = true
            scope.launch {
                Jarvis.state.collect { s ->
                    bubble?.color(when (s) { JState.Idle -> 0xFF3A3F4B.toInt(); JState.Listening -> 0xFF00E5FF.toInt(); JState.Thinking -> 0xFFFFB300.toInt(); JState.Done -> 0xFF00E676.toInt() })
                }
            }
        }
    }
    /** Din mein 3-4 baar ek halka sa dost wala message (sone ke time nahi). Home pe switch se band hota hai. */
    private fun checkPing() {
        val sp = getSharedPreferences("jarvis", MODE_PRIVATE)
        if (!sp.getBoolean("pings", true)) return
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
        val r = RoutineEngine.now(); val msg = r.ping ?: return
        val stamp = r.key + "_" + java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
        if (sp.getString("lastPing", "") == stamp) return
        sp.edit().putString("lastPing", stamp).apply()
        val n = Notification.Builder(this, "jarvis_chat").setContentTitle("Jarvis ${r.emoji}").setContentText(msg)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setAutoCancel(true)
            .setContentIntent(PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)).build()
        getSystemService(NotificationManager::class.java).notify(2, n)
    }
    private fun wakeOn() = getSharedPreferences("jarvis", MODE_PRIVATE).getBoolean("wake", true)
    private fun next() { if (wakeOn() || cmdMode) listen() else if (!bubbleOn()) stopSelf() }

    private fun listen() {
        sr?.destroy()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { stopSelf(); return }
        sr = SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(this)
            it.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (getSharedPreferences("jarvis", MODE_PRIVATE).getBoolean("hindi", false)) "hi-Latn" else "en-IN")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true))
        }
    }

    private fun wake() {
        sr?.cancel()
        runCatching { ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150) }
        cmdMode = true; Jarvis.state.value = JState.Listening
        Jarvis.speak("Haan bhai, bol.") { listen() }
    }

    private fun run(cmd: String) {
        cmdMode = false; Jarvis.state.value = JState.Thinking
        if (Jarvis.pending == null) Jarvis.speak("Haan bhai, kar raha hoon.")
        scope.launch {
            val r = Jarvis.handle(this@WakeService, cmd)
            Jarvis.speak(r.text, add = true) { finish() }
        }
    }

    private fun finish() {
        if (Jarvis.pending != null) { cmdMode = true; Jarvis.state.value = JState.Listening }
        else h.postDelayed({ if (Jarvis.state.value == JState.Done) Jarvis.state.value = JState.Idle }, 1500)
        next()
    }

    private fun best(b: Bundle?) = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""

    override fun onPartialResults(b: Bundle?) {
        if (!cmdMode && wakeRe.matches(best(b).trim())) wake()
    }

    override fun onResults(b: Bundle?) {
        val text = best(b)
        if (cmdMode) { if (text.isBlank()) { cmdMode = false; Jarvis.state.value = JState.Idle; next() } else run(text); return }
        val m = wakeRe.find(text)
        if (m == null) { next(); return }
        val rest = text.substring(m.range.last + 1).trim()
        if (rest.isBlank()) wake() else run(rest)
    }

    override fun onError(e: Int) {
        if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopSelf(); return }
        if (cmdMode) { cmdMode = false; Jarvis.pending = null; Jarvis.state.value = JState.Idle }
        h.postDelayed({ next() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 600)
    }

    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onEvent(t: Int, b: Bundle?) {}

    override fun onDestroy() { bubble?.hide(); sr?.destroy(); scope.cancel(); h.removeCallbacksAndMessages(null); super.onDestroy() }
}
