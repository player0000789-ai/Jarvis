package com.jarvis.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

object Looks { var ver by mutableIntStateOf(0) }
val MOODS = listOf("idle", "listening", "thinking", "happy", "focused", "funny", "serious", "calm")

fun avatarFile(c: Context, key: String) = File(c.filesDir, "avatar_$key.jpg")
fun loadAvatar(c: Context, key: String): ImageBitmap? = avatarFile(c, key).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path)?.asImageBitmap() }
fun saveAvatar(c: Context, key: String, uri: Uri) {
    val src = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
    val s = 512f / maxOf(src.width, src.height)
    val b = if (s < 1) Bitmap.createScaledBitmap(src, (src.width * s).toInt(), (src.height * s).toInt(), true) else src
    avatarFile(c, key).outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 90, it) }
}

/** Personality, avatar photos (har mood ke liye) aur awaaz (voice/pitch/speed) yahan set hoti hai. Photos sirf phone pe rehti hain. */
@Composable
fun LooksScreen(back: () -> Unit) {
    val c = LocalContext.current
    val sp = c.getSharedPreferences("jarvis", 0)
    var target by remember { mutableStateOf("idle") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) { saveAvatar(c, target, u); Looks.ver++ } }
    var persona by remember { mutableStateOf(sp.getString("persona", "") ?: "") }
    var pitch by remember { mutableStateOf(sp.getFloat("pitch", 1f)) }
    var rate by remember { mutableStateOf(sp.getFloat("rate", 1f)) }
    var voice by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Look & Voice", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.weight(1f))
            TextButton(onClick = back) { Text("Back") }
        }
        Text("Personality (apne words mein)", color = Color.Gray, modifier = Modifier.padding(top = 16.dp))
        OutlinedTextField(persona, { persona = it; sp.edit().putString("persona", it).apply() }, minLines = 3, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("jaise: thoda swagger, mazaakiya, seedha-saada, bada bhai type...") })
        Text("Avatar photos (har mood ki apni photo chun)", color = Color.Gray, modifier = Modifier.padding(top = 16.dp, bottom = 4.dp))
        MOODS.forEach { m ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                val img = remember(m, Looks.ver) { loadAvatar(c, m) }
                if (img != null) Image(img, null, Modifier.size(40.dp).clip(CircleShape), contentScale = ContentScale.Crop) else Spacer(Modifier.size(40.dp))
                Text(m, color = Color.White, modifier = Modifier.weight(1f).padding(start = 12.dp))
                TextButton(onClick = { target = m; pick.launch("image/*") }) { Text("Chun") }
                if (img != null) TextButton(onClick = { avatarFile(c, m).delete(); Looks.ver++ }) { Text("Hata") }
            }
        }
        Text("Awaaz", color = Color.Gray, modifier = Modifier.padding(top = 16.dp))
        Text("Pitch %.1f".format(pitch), color = Color.White)
        Slider(pitch, { pitch = it; sp.edit().putFloat("pitch", it).apply() }, valueRange = 0.6f..1.6f)
        Text("Speed %.1f".format(rate), color = Color.White)
        Slider(rate, { rate = it; sp.edit().putFloat("rate", it).apply() }, valueRange = 0.6f..1.6f)
        Button(onClick = { voice = Jarvis.nextVoice(); Jarvis.speak("Haan yaar, ye meri nayi awaaz hai.") }) { Text("Awaaz badal ($voice)") }
    }
}
