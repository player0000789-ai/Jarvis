package com.jarvis.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Jarvis ki yaaddasht. Sirf phone pe rehti hai. "bhool ja" bolega to sab saaf. Password/OTP/number kabhi save nahi hota. */
const val DEFAULT_PERSONA = "Dost jaisa relaxed aur baatuni. Mazaakiya, thoda swag, par kabhi zyada serious nahi. Calm aur confident, dost ke liye loyal. Chhote natural jawab, sawal puchh ke baat aage badhata hai, apni daily life ki baatein bhi share karta hai."

object Memory {
    private fun sp(c: Context) = c.getSharedPreferences("jarvis_mem", 0)
    private val blocked = Regex("password|passwd|otp|\\bpin\\b|cvv|card|\\d{6,}", RegexOption.IGNORE_CASE)

    private fun list(c: Context, k: String): List<String> {
        val a = JSONArray(sp(c).getString(k, "[]")); return List(a.length()) { a.getString(it) }
    }
    private fun put(c: Context, k: String, l: List<String>) = sp(c).edit().putString(k, JSONArray(l).toString()).apply()

    fun facts(c: Context) = list(c, "facts")
    fun addFact(c: Context, s: String): Boolean {
        val t = s.trim().take(160)
        if (t.isBlank() || blocked.containsMatchIn(t)) return false
        put(c, "facts", (facts(c).filter { it != t } + t).takeLast(40)); return true
    }
    fun addRoutine(c: Context, s: String) { if (!blocked.containsMatchIn(s)) put(c, "routines", (list(c, "routines") + s.take(200)).takeLast(8)) }

    fun alias(c: Context, name: String): String? = JSONObject(sp(c).getString("alias", "{}")!!).optString(name).ifEmpty { null }
    fun setAlias(c: Context, a: String, b: String) {
        val j = JSONObject(sp(c).getString("alias", "{}")!!); j.put(a.lowercase(), b.lowercase()); sp(c).edit().putString("alias", j.toString()).apply()
    }

    fun bump(c: Context, cmd: String) {
        val j = JSONObject(sp(c).getString("counts", "{}")!!); val k = cmd.lowercase().trim().take(60)
        j.put(k, j.optInt(k) + 1)
        if (j.length() > 60) j.keys().asSequence().minByOrNull { j.getInt(it) }?.let { j.remove(it) }
        sp(c).edit().putString("counts", j.toString()).apply()
    }
    private fun top(c: Context): List<String> {
        val j = JSONObject(sp(c).getString("counts", "{}")!!)
        return j.keys().asSequence().filter { j.getInt(it) >= 2 }.sortedByDescending { j.getInt(it) }.take(5).toList()
    }

    fun forgetAll(c: Context) { sp(c).edit().clear().apply() }

    /** Ye text agent ke prompt mein jaata hai taaki wo tujhe jaan ke kaam kare. */
    fun context(c: Context): String {
        val f = facts(c); val h = top(c); val r = list(c, "routines").takeLast(3)
        val p = (c.getSharedPreferences("jarvis", 0).getString("persona", "") ?: "").ifBlank { DEFAULT_PERSONA }
        return buildString {
            append("Personality the user wants you to have: $p\n")
            RoutineEngine.now().let { rt -> append("Right now you (Jarvis) are: ${rt.line}. Mention your day casually now and then, do not overdo it.${if (rt.sleepy) " You are sleepy: reply a bit groggy and joke about it, but still help fully." else ""}\n") }
            append("About the user (learned so far):\n"); f.forEach { append("- $it\n") }
            if (h.isNotEmpty()) append("Often says: ${h.joinToString(" | ")}\n")
            if (r.isNotEmpty()) append("Past tasks that worked: ${r.joinToString(" || ")}\n")
            append("\n")
        }
    }
}

object MemoryCmd : Command {
    override val ask get() = false
    override fun matches(t: String) = Regex("\\b(yaad rakh\\w*|remember|bhool ja|bhul ja|forget|kya yaad hai)\\b|^\\w+ matlab \\w+").containsMatchIn(t)
    override suspend fun run(c: Context, raw: String): Reply {
        val t = raw.lowercase()
        return when {
            Regex("bhool ja|bhul ja|forget").containsMatchIn(t) -> Reply("Pakka sab bhula du yaar? Haan bol de.", { Memory.forgetAll(c); "Ho gaya, sab bhool gaya." })
            "kya yaad hai" in t -> Memory.facts(c).takeLast(5).let { if (it.isEmpty()) Reply("Abhi to kuch khaas yaad nahi yaar, bata na kuch.") else Reply("Ye yaad hai: " + it.joinToString(". ")) }
            Regex("^(\\w+) matlab (.+)$").find(t) != null -> Regex("^(\\w+) matlab (.+)$").find(t)!!.let {
                Memory.setAlias(c, it.groupValues[1], it.groupValues[2]); Reply("Done yaar, ${it.groupValues[1]} matlab ${it.groupValues[2]}.") }
            else -> {
                val fact = raw.replace(Regex("yaad rakh\\w*|remember( that)?", RegexOption.IGNORE_CASE), " ").replace(Regex("^\\s*(ki|ye)\\s+", RegexOption.IGNORE_CASE), "").trim()
                if (Memory.addFact(c, fact)) Reply("Pakka yaar, yaad rakhunga.") else Reply("Ye wali cheez (password/number) main yaad nahi rakhta yaar.")
            }
        }
    }
}
