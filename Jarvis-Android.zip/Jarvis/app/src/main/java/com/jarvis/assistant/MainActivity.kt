package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); Jarvis.init(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                App(tick, prefs.getBoolean("wake", true), { tick++ }) { on -> prefs.edit().putBoolean("wake", on).apply(); sync(); tick++ }
            }
        }
    }
    override fun onResume() { super.onResume(); tick++; sync() }

    private fun sync() {
        val i = Intent(this, WakeService::class.java)
        if (has(Manifest.permission.RECORD_AUDIO) && (prefs.getBoolean("wake", true) || prefs.getBoolean("bubble", true))) startForegroundService(i) else stopService(i)
    }
}

@Composable
fun App(tick: Int, wake: Boolean, refresh: () -> Unit, setWake: (Boolean) -> Unit) {
    val c = LocalContext.current
    var perms by remember { mutableStateOf(false) }
    var looks by remember { mutableStateOf(false) }
    val micOk = tick >= 0 && c.has(Manifest.permission.RECORD_AUDIO)
    Surface(Modifier.fillMaxSize(), color = Color.Black) {
        when {
            !micOk || perms -> Perms(tick, micOk, refresh) { perms = false }
            looks -> LooksScreen { looks = false }
            else -> Home(wake, setWake, { looks = true }) { perms = true }
        }
    }
}

private class P(val name: String, val why: String, val ok: Boolean, val act: () -> Unit)

@Composable
fun Perms(tick: Int, micOk: Boolean, refresh: () -> Unit, done: () -> Unit) {
    val c = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }
    val media = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
    val a11y = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)?.contains(c.packageName) == true
    val rows = listOf(
        P("Microphone", "\"Jarvis\" sunne ke liye (zaroori)", c.has(Manifest.permission.RECORD_AUDIO)) { launcher.launch(Manifest.permission.RECORD_AUDIO) },
        P("Notifications", "Background listening ka indicator", Build.VERSION.SDK_INT < 33 || c.has(Manifest.permission.POST_NOTIFICATIONS)) { launcher.launch(Manifest.permission.POST_NOTIFICATIONS) },
        P("Photos", "Photo/screenshot dhoondne ke liye", c.has(media)) { launcher.launch(media) },
        P("Accessibility", "Typing, tap, back/home ke liye", a11y) { c.go(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
        P("Display over apps", "Background se apps kholne ke liye", Settings.canDrawOverlays(c)) { c.go(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}"))) },
        P("Battery unrestricted", "Background mein Jarvis band na ho", c.getSystemService(android.os.PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)) { c.go(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${c.packageName}"))) },
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Text("Pehle permissions de de, bhai", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Jo allow karega wahi use hoga. Kuch bhi chupke se nahi.", color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))
        rows.forEach { r ->
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(r.name, color = Color.White, fontSize = 16.sp); Text(r.why, color = Color.Gray, fontSize = 12.sp) }
                if (r.ok) Text("On", color = Color(0xFF00E676)) else Button(onClick = r.act) { Text("Allow") }
            }
        }
        val sp = c.getSharedPreferences("jarvis", 0)
        var key by remember { mutableStateOf(sp.getString("key", "") ?: "") }
        OutlinedTextField(key, { key = it; sp.edit().putString("key", it.trim()).apply() }, label = { Text("Anthropic API key (har kaam karne ke liye)") },
            singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth().padding(top = 12.dp))
        Spacer(Modifier.height(16.dp))
        Button(onClick = done, enabled = micOk, modifier = Modifier.fillMaxWidth()) { Text("Chal bhai") }
    }
}

@Composable
fun Home(wake: Boolean, setWake: (Boolean) -> Unit, openLooks: () -> Unit, openPerms: () -> Unit) {
    val c = LocalContext.current
    val sp = c.getSharedPreferences("jarvis", 0)
    var ask by remember { mutableStateOf(sp.getBoolean("ask", true)) }
    var bub by remember { mutableStateOf(sp.getBoolean("bubble", true)) }
    var hi by remember { mutableStateOf(sp.getBoolean("hindi", false)) }
    var pings by remember { mutableStateOf(sp.getBoolean("pings", true)) }
    val st by Jarvis.state.collectAsState()
    val mood by Jarvis.mood.collectAsState()
    val speaking by Jarvis.speaking.collectAsState()
    val rt = remember(st) { RoutineEngine.now() }
    val shown = if (st == JState.Idle) rt.mood else mood
    val akey = when (st) { JState.Idle -> "idle"; JState.Listening -> "listening"; JState.Thinking -> "thinking"; JState.Done -> mood }
    val img = remember(akey, Looks.ver) { loadAvatar(c, akey) ?: loadAvatar(c, "idle") }
    val hist by Jarvis.history.collectAsState()
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(
        1f, if (st == JState.Listening) 1.15f else 1.03f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "s")
    val col = when (st) { JState.Idle -> Color(0xFF3A3F4B); JState.Listening -> Color(0xFF00E5FF); JState.Thinking -> Color(0xFFFFB300); JState.Done -> Color(0xFF00E676) }
    val label = when (st) { JState.Idle -> "\"Jarvis\" bol ya mic dabा"; JState.Listening -> "Listening…"; JState.Thinking -> "Thinking…"; JState.Done -> "Done ✓" }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Jarvis", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Row { TextButton(onClick = openLooks) { Text("Look") }; TextButton(onClick = openPerms) { Text("Permissions") } }
        }
        Spacer(Modifier.height(32.dp))
        Box(Modifier.size(190.dp).scale(pulse).background(col.copy(alpha = .25f), CircleShape)
            .clickable { c.startForegroundService(Intent(c, WakeService::class.java).setAction("TAP")) }, contentAlignment = Alignment.Center) {
            if (img != null) Image(img, null, Modifier.size(150.dp).clip(CircleShape).border(3.dp, col, CircleShape), contentScale = ContentScale.Crop)
            else LiveAvatar(Modifier.size(150.dp).clip(CircleShape).border(3.dp, col, CircleShape), shown, speaking, rt)
        }
        Spacer(Modifier.height(20.dp))
        Text(label, color = Color.White, fontSize = 20.sp)
        Text("${rt.emoji} ${rt.line}", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        Row(Modifier.fillMaxWidth().padding(top = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Wake word (\"Jarvis\")", color = Color.Gray, modifier = Modifier.weight(1f)); Switch(wake, setWake)
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Pehle mujhse puchh (ask first)", color = Color.Gray, modifier = Modifier.weight(1f)); Switch(ask, { ask = it; sp.edit().putBoolean("ask", it).apply() })
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Floating mic bubble", color = Color.Gray, modifier = Modifier.weight(1f))
            Switch(bub, { bub = it; sp.edit().putBoolean("bubble", it).apply(); c.startForegroundService(Intent(c, WakeService::class.java)) })
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Hinglish mic (hi-Latn)", color = Color.Gray, modifier = Modifier.weight(1f))
            Switch(hi, { hi = it; sp.edit().putBoolean("hindi", it).apply() })
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Dost ke messages (din mein 3-4)", color = Color.Gray, modifier = Modifier.weight(1f))
            Switch(pings, { pings = it; sp.edit().putBoolean("pings", it).apply() })
        }
        Text("Recent", color = Color.Gray, modifier = Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 4.dp))
        LazyColumn(Modifier.fillMaxWidth()) { items(hist.takeLast(10).reversed()) { Text(it, color = Color.LightGray, fontSize = 14.sp, modifier = Modifier.padding(vertical = 4.dp)) } }
    }
}
