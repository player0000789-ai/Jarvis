package com.jarvis.assistant

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.abs

/** Floating mic bubble: kisi bhi app ke upar dikhta hai, drag kar sakta hai, tap = Jarvis sunna shuru. Rang state ke saath badalta hai. */
class Bubble(private val c: Context, private val onTap: () -> Unit) {
    private val wm = c.getSystemService(WindowManager::class.java)
    private var v: TextView? = null
    private val size = (56 * c.resources.displayMetrics.density).toInt()
    private val lp = WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        .apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 400 }

    fun show() {
        if (v != null || !Settings.canDrawOverlays(c)) return
        val t = TextView(c).apply {
            text = "🎤"; textSize = 22f; gravity = Gravity.CENTER; alpha = .9f
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF3A3F4B.toInt()) }
        }
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false
        t.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - dx).toInt(); val my = (e.rawY - dy).toInt()
                    if (abs(mx) > 10 || abs(my) > 10) moved = true
                    lp.x = sx + mx; lp.y = sy + my; wm.updateViewLayout(t, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap()
            }
            true
        }
        wm.addView(t, lp); v = t
    }
    fun color(col: Int) { (v?.background as? GradientDrawable)?.setColor(col) }
    fun hide() { v?.let { runCatching { wm.removeView(it) } }; v = null }
}
