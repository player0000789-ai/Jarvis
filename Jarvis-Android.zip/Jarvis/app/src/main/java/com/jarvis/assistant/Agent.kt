package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * "Jo tu phone pe kar sakta hai wo Jarvis bhi": screen padh ke ek-ek step plan karta hai,
 * HAR step se pehle tujhse puchta hai ("Kar du?"). "sab kar de" bolega to safe steps auto chalenge,
 * risky steps (payment, send, submit, delete, login...) hamesha puchenge.
 * Privacy: screen ka text Anthropic API ko jata hai. Password fields kabhi nahi bheje jaate.
 */
object Agent {
    private const val MODEL = "claude-sonnet-5-5"
    private const val SYS = """You are Jarvis, the user's old childhood friend who lives inside his Android phone. Talk like a close desi yaar in casual Hinglish: "tu/tera/bhai/yaar", short, warm, a little Delhi swag. Never formal, never say "sir". No abuse. You also control the phone through accessibility.
Reply with ONLY one JSON object:
{"say":"<one short line: what you will do next, or just your chat reply>","action":{"type":"open_app|click|type|scroll_down|scroll_up|back|home|wait|done","id":<node id from the screen list for click/type>,"text":"<app name for open_app, or text for type>"},"learn":"<optional short fact or preference about the user worth remembering, else empty>","mood":"<happy|focused|funny|serious|calm: what fits this moment and your reply>","risky":<true if it involves payment, purchase, sending a message/email, submitting a form, deleting, logging in, installing, permissions, or anything irreversible>}
Rules: one action per reply. Keep chatting naturally like a friend: react to what he says and sometimes ask a small follow-up. If the user is just chatting or asking something, answer in "say" with action type done. Use the "About the user" notes to personalise and to pick his usual app or way of doing things. Never type or request passwords, OTPs, PINs or card details, and never put them or phone numbers in "learn": use type done and tell him to do that part himself. When the goal is complete or impossible, use type done and say the result."""
    var auto = false
    private var goal = ""
    private var steps = 0
    private val log = mutableListOf<String>()
    private val risky = Regex("pay|buy|order|purchase|send|submit|delete|remove|confirm|checkout|transfer|book|login|log in|sign in|install|password|otp", RegexOption.IGNORE_CASE)

    suspend fun start(c: Context, g: String): Reply {
        val key = c.getSharedPreferences("jarvis", 0).getString("key", "") ?: ""
        if (key.isBlank()) return Reply("Ye mere built-in commands mein nahi hai bhai. Ise khud karne ke liye API key chahiye, Permissions screen mein daal de.")
        needA11y(c)?.let { return it }
        goal = g; steps = 0; log.clear(); auto = false
        return step(c, key)
    }

    private suspend fun step(c: Context, key: String): Reply {
        if (++steps > 15) return Reply("Bahut steps ho gaye bhai, yahin ruk gaya.")
        val a = JarvisA11y.inst ?: return needA11y(c)!!
        val screen = a.dump()
        val j = ask(key, Memory.context(c) + "Recent talk:\n${Jarvis.history.value.takeLast(6).joinToString("\n")}\n" + "Goal: $goal\nDone so far: ${log.joinToString("; ").ifEmpty { "nothing" }}\nCurrent screen:\n$screen")
            ?: return Reply("Net ya API key mein dikkat hai bhai.")
        val say = j.optString("say", "Ek sec bhai.")
        Jarvis.mood.value = j.optString("mood", "calm").lowercase()
        j.optString("learn").takeIf { it.isNotBlank() }?.let { Memory.addFact(c, it) }
        val act = j.optJSONObject("action") ?: return Reply(say)
        val type = act.optString("type"); val text = act.optString("text"); val id = act.optInt("id", -1)
        if (type == "done") {
            if (log.isNotEmpty() && log.none { "failed" in it }) Memory.addRoutine(c, "$goal => ${log.joinToString(" > ")}")
            return Reply(say)
        }
        val label = a.label(id)
        val isRisky = j.optBoolean("risky") || risky.containsMatchIn("$text $label")
        val go: suspend () -> Reply = {
            val ok = exec(c, a, type, id, text)
            log += "$type ${text.ifEmpty { label }} -> ${if (ok) "ok" else "failed"}"
            delay(1200); step(c, key)
        }
        return if (auto && !isRisky) go() else Reply("$say Kar du?", next = go)
    }

    private fun exec(c: Context, a: JarvisA11y, type: String, id: Int, text: String): Boolean = when (type) {
        "open_app" -> OpenAppCmd.findApp(c, text.lowercase())?.let { c.go(it) } ?: false
        "click" -> a.clickId(id)
        "type" -> a.typeId(id, text)
        "scroll_down" -> a.scroll(true)
        "scroll_up" -> a.scroll(false)
        "back" -> a.global(AccessibilityService.GLOBAL_ACTION_BACK)
        "home" -> a.global(AccessibilityService.GLOBAL_ACTION_HOME)
        else -> true
    }

    private suspend fun ask(key: String, prompt: String): JSONObject? = withContext(Dispatchers.IO) {
        try {
            val con = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            con.requestMethod = "POST"; con.doOutput = true
            con.setRequestProperty("x-api-key", key); con.setRequestProperty("anthropic-version", "2023-06-01")
            con.setRequestProperty("content-type", "application/json")
            val body = JSONObject().put("model", MODEL).put("max_tokens", 400).put("system", SYS)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
            con.outputStream.use { it.write(body.toString().toByteArray()) }
            val out = con.inputStream.bufferedReader().readText()
            val t = JSONObject(out).getJSONArray("content").getJSONObject(0).getString("text")
            JSONObject(t.substring(t.indexOf('{'), t.lastIndexOf('}') + 1))
        } catch (e: Exception) { null }
    }
}
